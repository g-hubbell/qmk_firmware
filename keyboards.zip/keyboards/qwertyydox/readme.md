QWERTYYdox
====

![QWERTYYdox](https://imgur.com/gallery/Pwwb0Q0)


A split ergo 4x7 keyboard with 3 thumb keys and 2 Y keys.

**Status** The QWERTYYdox is a personal project, however it is completely functional.  

Keyboard Maintainer: /u/aydenvis  

Hardware Supported: Pro Micro (ATmega32U4) 

Hardware Availability: The whole thing is handwired with plates cut by [/u/JOlimon](stratakb.com)


Make example for this keyboard (after setting up your build environment):

    make qwertyydox/rev1:default

Example of flashing this keyboard:

    make qwertyydox/rev1:default:avrdude

See [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) then the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information.

