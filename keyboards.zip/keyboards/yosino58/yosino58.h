#pragma once

#ifdef KEYBOARD_yosino58_rev1
  #include "rev1.h"
#endif
