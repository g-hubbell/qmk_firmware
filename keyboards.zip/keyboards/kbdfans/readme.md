# KBDFans

KBDfans is a keyboard retailer located in China. 

## Online Stores

**Website:** https://kbdfans.cn/  
**AliExpress:** https://kbdfans.aliexpress.com/  
**eBay:** https://www.ebay.com/str/KBDfans/  
**Taobao:** https://yikewaishe.taobao.com/  

## Social Media

**Discord:** https://discord.gg/HMZKDhn  
**Facebook:** https://www.facebook.com/KBDfanskeyboard/  
**Instagram:** https://www.instagram.com/kbdfans.cn/  

