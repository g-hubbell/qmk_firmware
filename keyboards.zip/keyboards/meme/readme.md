# Meme

![meme](imgur.com image replace me!)

65% gasket mount keyboard.   

Keyboard Maintainer: [MechMerlin](https://github.com/mechmerlin)   
Hardware Supported: Meme   
Hardware Availability: [Switchmod Keyboards](http://www.switchmod.net/)   

Make example for this keyboard (after setting up your build environment):

    make meme:default

See [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) then the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information.
