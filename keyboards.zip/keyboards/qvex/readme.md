# QVEX

QVEX is a keyboard vendor based in Czechia

## Online Stores

**Website:** https://www.tindie.com/products/qvex_tech/qvex-lynepad-macro-keypad/
