#pragma once

#include "quantum.h"

#ifdef KEYBOARD_8pack_rev11
  #include "rev11.h"
#endif

#ifdef KEYBOARD_8pack_rev12
  #include "rev12.h"
#endif