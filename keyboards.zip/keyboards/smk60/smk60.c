/**
 * smk60.c
 */

#include "smk60.h"
