# 60% pcb for smk 2nd switch

A gh60 campatible pcb for [smk 2nd switch](https://deskthority.net/wiki/SMK_second_generation)

Keyboard Maintainer: [astro](https://github.com/yulei)  
Hardware Supported: GH60 campatible 

Make example for this keyboard (after setting up your build environment):

    make smk60:default

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).
