# MT40

[MT40](https://i.imgur.com/0opsDkt.jpg)

A 40% Ortholinear Keyboard

* Keyboard Maintainer: QMK Community
* Hardware Supported: MT40
* Hardware Availability: <https://world.taobao.com/item/548335974877.htm?fromSite=main&spm=a312a.7700824.w4002-6810221593.51.670e68a08mRh69>

Make example for this keyboard (after setting up your build environment):

    make mt40:default

Flashing example for this keyboard ([after setting up the bootloadHID flashing environment](https://docs.qmk.fm/#/flashing_bootloadhid))

    make mt40:default:flash

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).
