Omnikey BH PCB
===

A replacement PCB for Omnikey keyboards. Supports 101, 102, Plus, Ultra T, Ultra, Prime and Stellar, as well as customs.

Keyboard Maintainer: QMK Community and blindassassin111  
Hardware Supported: Omnikey BH PCB  
Hardware Availability: https://deskthority.net/group-buys-f50/omnikey-replacement-pcb-t18276.html

Make example for this keyboard (after setting up your build environment):

    make omnikey_bh:default

See [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) then the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information.
