# Welcome to my keyboard folder

In here, you can find:
- Chinese PCB that doesn't have source code (lost contact of Maker, can't found on Taobao, ... etc)
- My keyboard (ETA on future)

## Contact me if you have any problem

**Discord:** HorrorTroll#0975  
**Facebook:** https://www.facebook.com/PhamChonChe.Duc/  
**Email:** sonicvipduc@gmail.com
