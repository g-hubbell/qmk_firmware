# Sparrow62

Sparrow62 inspired from Lily58.

* Keyboard Maintainer: [Atsushi Morimoto](https://github.com/74th)
* Hardware Availability: https://booth.pm/ja/items/2525427
* Build Guide: https://github.com/74th/sparrow62-buildguide

Make example for this keyboard (after setting up your build environment):

    make sparrow62:default

Flashing example for this keyboard:

    make sparrow62:default:flash

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).
