# ebastler

I'm a hobbyist designing keyboards for fun. [My homepage](https://mpwr.xyz). All my personal keyboard projects are open source and can be found in my github repo(s), linked below. Commissions may remain closed source.


* [isometria<sup>75</sup>](isometria_75) - 75% ISO-only board with rotary encoder, RGB underglow and single color backlight. [Github repo](https://github.com/ebastler/isometria-75).
