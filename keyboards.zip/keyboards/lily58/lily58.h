#pragma once

#ifdef KEYBOARD_lily58_rev1
    #include "rev1.h"
#elif KEYBOARD_lily58_light
    #include "light.h"
#elif KEYBOARD_lily58_glow_enc
    #include "glow_enc.h"
#endif
