#pragma once

#ifdef KEYBOARD_ergoslab_rev1
    #include "rev1.h"
#endif

#include "quantum.h"
