#pragma once

#ifdef KEYBOARD_ergotravel_rev1
    #include "rev1.h"
#endif

#include "quantum.h"
